.. dyntapy documentation master file, created by
   sphinx-quickstart on Mon Feb 28 16:14:10 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to dyntapy's documentation!
===================================

You can find dyntapy's source code, with accompanying installation instructions, `here <https://gitlab.kuleuven.be/ITSCreaLab/public-toolboxes/dyntapy>`_.

Tutorials are available in a separate `repository <https://gitlab.kuleuven.be/ITSCreaLab/public-toolboxes/dyntapy-tutorials>`_.
They can be run without installation from the browser using Binder. 

.. image:: https://mybinder.org/badge_logo.svg
 :target: https://mybinder.org/v2/git/https%3A%2F%2Fgitlab.kuleuven.be%2FITSCreaLab%2Fpublic-toolboxes%2Fdyntapy-tutorials/HEAD

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   source/dyntapy
   

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
